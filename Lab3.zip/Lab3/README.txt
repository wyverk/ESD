C code in /software

main folder is nios software, other one is to configure NIOS or sth
storage folder has file for part 1